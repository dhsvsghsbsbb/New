
import React, { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Camera } from "lucide-react";

const Profile = () => {
  const { user, updateProfile } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user?.name || "");
  const [profileImage, setProfileImage] = useState<string | undefined>(user?.profileImage);

  const handleUpdateProfile = () => {
    updateProfile({ name, profileImage });
    setIsEditing(false);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <h1 className="text-3xl font-bold mb-8 text-center">الملف الشخصي</h1>
      <Tabs defaultValue="profile">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="profile">المعلومات الشخصية</TabsTrigger>
          <TabsTrigger value="account">إعدادات الحساب</TabsTrigger>
        </TabsList>
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>المعلومات الشخصية</CardTitle>
              <CardDescription>يمكنك هنا عرض وتحديث معلوماتك الشخصية.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                <div className="flex flex-col md:flex-row gap-8 items-center">
                  <div className="relative">
                    <Avatar className="w-32 h-32">
                      <AvatarImage src={profileImage} />
                      <AvatarFallback className="default-avatar text-4xl">
                        {user?.name?.substring(0, 1)}
                      </AvatarFallback>
                    </Avatar>
                    {isEditing && (
                      <label
                        htmlFor="profile-image"
                        className="absolute bottom-0 right-0 bg-sawti-blue text-white p-2 rounded-full cursor-pointer"
                      >
                        <input
                          id="profile-image"
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handleImageChange}
                        />
                        <Camera className="h-4 w-4" />
                      </label>
                    )}
                  </div>
                  <div className="flex-grow space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">الاسم</Label>
                      {isEditing ? (
                        <Input
                          id="name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                        />
                      ) : (
                        <div className="p-2 border rounded-md bg-gray-50">
                          {user?.name}
                        </div>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">البريد الإلكتروني</Label>
                      <div className="p-2 border rounded-md bg-gray-50">
                        {user?.email}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              {isEditing ? (
                <div className="space-x-2 rtl:space-x-reverse">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsEditing(false);
                      setName(user?.name || "");
                      setProfileImage(user?.profileImage);
                    }}
                  >
                    إلغاء
                  </Button>
                  <Button onClick={handleUpdateProfile} className="bg-sawti-blue hover:bg-blue-700">
                    حفظ التغييرات
                  </Button>
                </div>
              ) : (
                <Button onClick={() => setIsEditing(true)} className="bg-sawti-blue hover:bg-blue-700">
                  تعديل الملف الشخصي
                </Button>
              )}
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>إعدادات الحساب</CardTitle>
              <CardDescription>إدارة إعدادات حسابك وتفضيلاتك.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">تغيير كلمة المرور</h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="current-password">كلمة المرور الحالية</Label>
                    <Input id="current-password" type="password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="new-password">كلمة المرور الجديدة</Label>
                    <Input id="new-password" type="password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">تأكيد كلمة المرور</Label>
                    <Input id="confirm-password" type="password" />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button className="bg-sawti-blue hover:bg-blue-700">
                تحديث كلمة المرور
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Profile;
