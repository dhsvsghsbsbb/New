
import React, { useState } from "react";
import { products } from "@/data/products";
import ProductCard from "@/components/ProductCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Search, SlidersHorizontal, X } from "lucide-react";

// استخراج الفئات الفريدة من المنتجات
const categories = Array.from(new Set(products.map((product) => product.category)));

const Products = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState({ min: 0, max: 1000 });
  const [showFilters, setShowFilters] = useState(false);

  // تصفية المنتجات بناءً على معايير البحث والتصفية
  const filteredProducts = products.filter((product) => {
    // فلترة حسب البحث
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          product.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    // فلترة حسب الفئات المحددة
    const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(product.category);
    
    // فلترة حسب نطاق السعر
    const matchesPrice = product.price >= priceRange.min && product.price <= priceRange.max;
    
    return matchesSearch && matchesCategory && matchesPrice;
  });

  // التبديل بين تحديد فئة وإلغاء تحديدها
  const toggleCategory = (category: string) => {
    if (selectedCategories.includes(category)) {
      setSelectedCategories(selectedCategories.filter((c) => c !== category));
    } else {
      setSelectedCategories([...selectedCategories, category]);
    }
  };

  // إعادة تعيين المرشحات
  const resetFilters = () => {
    setSearchQuery("");
    setSelectedCategories([]);
    setPriceRange({ min: 0, max: 1000 });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center">منتجاتنا</h1>
      
      {/* شريط البحث والتصفية */}
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="ابحث عن المنتجات..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 w-full"
          />
        </div>
        <Button
          variant="outline"
          className="md:w-auto flex items-center gap-2"
          onClick={() => setShowFilters(!showFilters)}
        >
          <SlidersHorizontal className="h-4 w-4" />
          <span>تصفية</span>
          {(selectedCategories.length > 0 || priceRange.min > 0 || priceRange.max < 1000) && (
            <span className="bg-sawti-blue text-white rounded-full w-5 h-5 flex items-center justify-center text-xs ml-2">
              {selectedCategories.length + (priceRange.min > 0 || priceRange.max < 1000 ? 1 : 0)}
            </span>
          )}
        </Button>
      </div>
      
      <div className="flex flex-col lg:flex-row gap-8">
        {/* مرشحات للشاشات المتوسطة والكبيرة */}
        <div className={`lg:w-1/4 p-4 bg-white rounded-lg shadow-sm ${showFilters ? 'block' : 'hidden lg:block'}`}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-lg">المرشحات</h3>
            <Button variant="ghost" size="sm" onClick={resetFilters} className="text-sm">
              إعادة تعيين
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setShowFilters(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          
          <div className="space-y-6">
            {/* فئات المنتجات */}
            <div>
              <h4 className="font-medium mb-2">الفئات</h4>
              <div className="space-y-2">
                {categories.map((category) => (
                  <div key={category} className="flex items-center gap-2">
                    <Checkbox
                      id={`category-${category}`}
                      checked={selectedCategories.includes(category)}
                      onCheckedChange={() => toggleCategory(category)}
                    />
                    <Label htmlFor={`category-${category}`} className="cursor-pointer">
                      {category}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
            
            {/* نطاق السعر */}
            <div>
              <h4 className="font-medium mb-2">
                السعر ({priceRange.min} - {priceRange.max} ر.س)
              </h4>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <Input
                    type="number"
                    placeholder="الحد الأدنى"
                    value={priceRange.min}
                    onChange={(e) => setPriceRange({ ...priceRange, min: +e.target.value })}
                    className="w-full"
                    min="0"
                  />
                  <span>إلى</span>
                  <Input
                    type="number"
                    placeholder="الحد الأقصى"
                    value={priceRange.max}
                    onChange={(e) => setPriceRange({ ...priceRange, max: +e.target.value })}
                    className="w-full"
                    min="0"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* قائمة المنتجات */}
        <div className="flex-grow">
          {filteredProducts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-xl text-gray-500 mb-4">لم يتم العثور على منتجات تطابق بحثك</p>
              <Button variant="outline" onClick={resetFilters}>
                إعادة تعيين المرشحات
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Products;
