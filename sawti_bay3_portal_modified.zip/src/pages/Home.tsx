
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { products } from "@/data/products";
import ProductCard from "@/components/ProductCard";
import { useAuth } from "@/context/AuthContext";

const Home = () => {
  const { user } = useAuth();
  const featuredProducts = products.slice(0, 3);

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-sawti-lightblue py-16 px-4">
        <div className="container mx-auto flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 text-center md:text-right mb-8 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-sawti-dark">
              {user ? `مرحبًا ${user.name}!` : 'تسوق بثقة معنا'}
            </h1>
            <p className="text-lg mb-6 text-gray-600 max-w-lg mx-auto md:mx-0">
              اكتشف أفضل المنتجات بأفضل الأسعار. نحن نوفر لك مجموعة متنوعة من المنتجات عالية الجودة مع ضمان رضاك.
            </p>
            <div className="space-x-4 rtl:space-x-reverse">
              <Button
                asChild
                className="bg-sawti-blue hover:bg-blue-700"
              >
                <Link to="/products">تسوق الآن</Link>
              </Button>
              {!user && (
                <Button
                  asChild
                  variant="outline"
                  className="border-sawti-blue text-sawti-blue hover:bg-sawti-lightblue"
                >
                  <Link to="/login">تسجيل الدخول</Link>
                </Button>
              )}
            </div>
          </div>
          <div className="md:w-1/2">
            <div className="relative">
              <div className="w-full h-64 md:h-96 rounded-lg bg-gradient-to-r from-blue-400 to-purple-500 flex items-center justify-center">
                <img 
                  src="/placeholder.svg" 
                  alt="تسوق معنا"
                  className="w-3/4 h-3/4 object-contain" 
                />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-white p-3 rounded-lg shadow-lg">
                <p className="font-bold text-sawti-blue text-xl">خصم 30%</p>
                <p className="text-sm text-gray-600">على المنتجات الجديدة</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="section container mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-sawti-dark">المنتجات المميزة</h2>
          <Button asChild variant="link" className="text-sawti-blue">
            <Link to="/products">عرض الكل</Link>
          </Button>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="section bg-gray-50">
        <div className="container mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12 text-sawti-dark">
            لماذا تختارنا؟
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-white rounded-lg shadow-sm">
              <div className="w-16 h-16 rounded-full bg-sawti-lightblue flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-sawti-blue" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">منتجات عالية الجودة</h3>
              <p className="text-gray-600">نحرص على توفير منتجات ذات جودة عالية لضمان رضاك الكامل.</p>
            </div>
            <div className="text-center p-6 bg-white rounded-lg shadow-sm">
              <div className="w-16 h-16 rounded-full bg-sawti-lightblue flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-sawti-blue" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">أسعار تنافسية</h3>
              <p className="text-gray-600">نقدم أفضل الأسعار في السوق مع عروض حصرية لعملائنا.</p>
            </div>
            <div className="text-center p-6 bg-white rounded-lg shadow-sm">
              <div className="w-16 h-16 rounded-full bg-sawti-lightblue flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-sawti-blue" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">دعم متميز</h3>
              <p className="text-gray-600">فريق دعم متكامل متواجد لمساعدتك على مدار الساعة.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section bg-sawti-blue text-white">
        <div className="container mx-auto text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">انضم إلى مجتمعنا الآن</h2>
          <p className="mb-8 max-w-xl mx-auto">
            سجل حسابك الآن واحصل على خصم 10% على أول عملية شراء لك، بالإضافة إلى تحديثات حصرية عن أحدث المنتجات والعروض.
          </p>
          <Button
            asChild
            variant="outline"
            className="bg-white text-sawti-blue hover:bg-gray-100 border-white"
          >
            <Link to="/login">إنشاء حساب</Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-sawti-dark text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">صوتي بيع</h3>
              <p className="text-gray-300 mb-4">متجرك المفضل للتسوق عبر الإنترنت.</p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">روابط سريعة</h3>
              <ul className="space-y-2">
                <li><Link to="/" className="text-gray-300 hover:text-white">الرئيسية</Link></li>
                <li><Link to="/products" className="text-gray-300 hover:text-white">المنتجات</Link></li>
                <li><Link to="/login" className="text-gray-300 hover:text-white">تسجيل الدخول</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">تواصل معنا</h3>
              <p className="text-gray-300 mb-2">البريد الإلكتروني: info@sawti-bay3.com</p>
              <p className="text-gray-300">الهاتف: +966 12 345 6789</p>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-400">
            <p>© 2025 صوتي بيع. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;
