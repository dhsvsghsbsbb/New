
import { Product } from "@/types";

export const products: Product[] = [
  {
    id: "1",
    name: "ساعة ذكية",
    description: "ساعة ذكية متعددة الوظائف مع تتبع اللياقة البدنية ونظام تحديد المواقع",
    price: 199.99,
    image: "/placeholder.svg",
    category: "إلكترونيات",
  },
  {
    id: "2",
    name: "سماعات لاسلكية",
    description: "سماعات بلوتوث لاسلكية مع إلغاء الضوضاء النشط",
    price: 149.99,
    image: "/placeholder.svg",
    category: "إلكترونيات",
  },
  {
    id: "3",
    name: "حقيبة ظهر",
    description: "حقيبة ظهر متعددة الوظائف مقاومة للماء مع حماية للكمبيوتر المحمول",
    price: 79.99,
    image: "/placeholder.svg",
    category: "حقائب",
  },
  {
    id: "4",
    name: "كاميرا رقمية",
    description: "كاميرا رقمية عالية الدقة مع عدسة زووم وتثبيت الصورة",
    price: 449.99,
    image: "/placeholder.svg",
    category: "إلكترونيات",
  },
  {
    id: "5",
    name: "محفظة جلدية",
    description: "محفظة جلدية أنيقة مع حماية RFID",
    price: 49.99,
    image: "/placeholder.svg",
    category: "إكسسوارات",
  },
  {
    id: "6",
    name: "طابعة لاسلكية",
    description: "طابعة لاسلكية ملونة للمنزل أو المكتب",
    price: 129.99,
    image: "/placeholder.svg",
    category: "إلكترونيات",
  },
];
