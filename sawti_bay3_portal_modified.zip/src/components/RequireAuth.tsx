
import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";

interface RequireAuthProps {
  children: React.ReactNode;
}

const RequireAuth: React.FC<RequireAuthProps> = ({ children }) => {
  const { user, isLoading } = useAuth();
  const location = useLocation();

  // إذا كانت عملية التحميل قيد التنفيذ، اعرض حالة التحميل
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-sawti-blue"></div>
      </div>
    );
  }

  // إذا لم يكن المستخدم مسجل الدخول، أعد توجيهه إلى صفحة تسجيل الدخول
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // إذا كان المستخدم مسجل الدخول، اعرض المحتوى المحمي
  return <>{children}</>;
};

export default RequireAuth;
