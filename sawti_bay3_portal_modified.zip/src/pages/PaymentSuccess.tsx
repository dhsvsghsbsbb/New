
import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Check } from "lucide-react";

const PaymentSuccess = () => {
  // تمرير للأعلى عند تحميل الصفحة
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // تاريخ التسليم المتوقع (بعد 5 أيام من اليوم)
  const getEstimatedDeliveryDate = () => {
    const date = new Date();
    date.setDate(date.getDate() + 5);
    return date.toLocaleDateString("ar-SA", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  // إنشاء رقم طلب عشوائي
  const orderNumber = `ORD-${Math.floor(100000 + Math.random() * 900000)}`;

  return (
    <div className="container max-w-2xl mx-auto px-4 py-16">
      <Card className="text-center">
        <CardContent className="pt-6">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="h-10 w-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold mb-2">تم الدفع بنجاح!</h1>
          <p className="text-gray-600 mb-8">
            شكراً لطلبك! لقد تم استلام طلبك وهو قيد المعالجة الآن.
          </p>

          <div className="bg-gray-50 rounded-lg p-6 mb-8">
            <div className="space-y-4 text-right">
              <div className="flex justify-between">
                <span className="font-medium">رقم الطلب:</span>
                <span>{orderNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">تاريخ الطلب:</span>
                <span>
                  {new Date().toLocaleDateString("ar-SA", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">التسليم المتوقع:</span>
                <span>{getEstimatedDeliveryDate()}</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <p className="text-gray-600">
              سيتم إرسال تأكيد الطلب إلى بريدك الإلكتروني قريبًا.
            </p>
            <p className="text-gray-600">
              يمكنك متابعة حالة طلبك من خلال حسابك الشخصي.
            </p>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col gap-4 pb-6">
          <Button asChild className="bg-sawti-blue hover:bg-blue-700 w-full">
            <Link to="/products">متابعة التسوق</Link>
          </Button>
          <Button asChild variant="outline" className="w-full">
            <Link to="/profile">متابعة طلباتي</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default PaymentSuccess;
