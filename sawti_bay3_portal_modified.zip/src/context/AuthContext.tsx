
import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useToast } from "@/components/ui/use-toast";
import { User } from "@/types";

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => void;
  signUp: (email: string, password: string, name: string) => void;
  loginWithGoogle: () => void;
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;
}

const defaultUser: User = {
  id: "user-1",
  name: "أحمد محمد",
  email: "ahmed@example.com",
  profileImage: "/placeholder.svg",
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  // محاكاة التحقق من المستخدم عند تحميل الصفحة
  useEffect(() => {
    // تحقق مما إذا كان المستخدم قد سجل الدخول مسبقًا
    const storedUser = localStorage.getItem("user");
    
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    
    setIsLoading(false);
  }, []);

  // تخزين المستخدم في التخزين المحلي عند تغييره
  useEffect(() => {
    if (user) {
      localStorage.setItem("user", JSON.stringify(user));
    } else {
      localStorage.removeItem("user");
    }
  }, [user]);

  const login = (email: string, password: string) => {
    setIsLoading(true);
    
    // محاكاة تأخير الشبكة
    setTimeout(() => {
      setUser(defaultUser);
      toast({
        title: "تم تسجيل الدخول بنجاح",
        description: "مرحبًا بك في متجرنا",
      });
      setIsLoading(false);
    }, 1000);
  };

  const signUp = (email: string, password: string, name: string) => {
    setIsLoading(true);
    
    // محاكاة تأخير الشبكة
    setTimeout(() => {
      const newUser = {
        ...defaultUser,
        name,
        email,
      };
      
      setUser(newUser);
      toast({
        title: "تم إنشاء الحساب بنجاح",
        description: "مرحبًا بك في متجرنا",
      });
      setIsLoading(false);
    }, 1000);
  };

  const loginWithGoogle = () => {
    setIsLoading(true);
    
    // محاكاة تأخير الشبكة
    setTimeout(() => {
      setUser(defaultUser);
      toast({
        title: "تم تسجيل الدخول بنجاح",
        description: "مرحبًا بك من خلال حساب Google",
      });
      setIsLoading(false);
    }, 1000);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("user");
    toast({
      title: "تم تسجيل الخروج",
    });
  };

  const updateProfile = (data: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...data };
      setUser(updatedUser);
      toast({
        title: "تم تحديث الملف الشخصي",
      });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        login,
        signUp,
        loginWithGoogle,
        logout,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
