
import React from "react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShoppingCart } from "lucide-react";
import { Product } from "@/types";
import { useCart } from "@/context/CartContext";

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addItem } = useCart();

  return (
    <Card className="product-card h-full flex flex-col">
      <div className="aspect-square relative overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
        <div className="absolute top-2 right-2 bg-sawti-blue text-white px-2 py-1 text-xs rounded-full">
          {product.category}
        </div>
      </div>
      <CardContent className="pt-4 flex-grow">
        <h3 className="font-semibold text-lg mb-1">{product.name}</h3>
        <p className="text-muted-foreground text-sm mb-2 line-clamp-2">{product.description}</p>
        <p className="text-sawti-blue font-bold">{product.price.toLocaleString()} ر.س</p>
      </CardContent>
      <CardFooter className="pt-0 pb-4 px-4">
        <Button
          className="w-full bg-sawti-blue hover:bg-blue-700"
          onClick={() => addItem(product)}
        >
          <ShoppingCart className="mr-2 h-4 w-4" />
          إضافة إلى السلة
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProductCard;
