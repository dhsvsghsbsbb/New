
import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useToast } from "@/components/ui/use-toast";
import { CartItem, Product } from "@/types";

interface CartContextType {
  items: CartItem[];
  addItem: (product: Product) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  totalItems: number;
  totalPrice: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
};

export const CartProvider = ({ children }: { children: ReactNode }) => {
  const [items, setItems] = useState<CartItem[]>([]);
  const { toast } = useToast();

  // استرجاع سلة المنتجات من التخزين المحلي عند تحميل الصفحة
  useEffect(() => {
    const storedItems = localStorage.getItem("cart");
    if (storedItems) {
      try {
        setItems(JSON.parse(storedItems));
      } catch (error) {
        console.error("Error parsing cart data:", error);
        localStorage.removeItem("cart");
      }
    }
  }, []);

  // تخزين سلة المنتجات في التخزين المحلي عند التغيير
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(items));
  }, [items]);

  const addItem = (product: Product) => {
    setItems((currentItems) => {
      // التحقق مما إذا كان المنتج موجودًا بالفعل في السلة
      const existingItem = currentItems.find(
        (item) => item.product.id === product.id
      );

      if (existingItem) {
        // زيادة الكمية إذا كان المنتج موجودًا بالفعل
        const updatedItems = currentItems.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
        
        toast({
          title: "تم تحديث السلة",
          description: `تم زيادة كمية ${product.name}`,
        });
        
        return updatedItems;
      } else {
        // إضافة المنتج الجديد إلى السلة
        toast({
          title: "تمت الإضافة إلى السلة",
          description: `تم إضافة ${product.name} إلى سلة المشتريات`,
        });
        
        return [...currentItems, { product, quantity: 1 }];
      }
    });
  };

  const removeItem = (productId: string) => {
    setItems((currentItems) => {
      const itemToRemove = currentItems.find(
        (item) => item.product.id === productId
      );
      
      if (itemToRemove) {
        toast({
          title: "تمت إزالة المنتج",
          description: `تمت إزالة ${itemToRemove.product.name} من سلة المشتريات`,
        });
      }
      
      return currentItems.filter((item) => item.product.id !== productId);
    });
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity < 1) {
      removeItem(productId);
      return;
    }

    setItems((currentItems) =>
      currentItems.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setItems([]);
    toast({
      title: "تم تفريغ السلة",
      description: "تمت إزالة جميع المنتجات من سلة المشتريات",
    });
  };

  // حساب إجمالي العناصر
  const totalItems = items.reduce((total, item) => total + item.quantity, 0);

  // حساب إجمالي السعر
  const totalPrice = items.reduce(
    (total, item) => total + item.product.price * item.quantity,
    0
  );

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        totalItems,
        totalPrice,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
