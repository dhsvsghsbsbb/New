
import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ShoppingCart, User, Menu, X } from "lucide-react";

const Navbar = () => {
  const { user, logout } = useAuth();
  const { totalItems } = useCart();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <nav className="sticky top-0 z-50 bg-white shadow-sm border-b">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <span className="text-sawti-blue font-bold text-2xl">صوتي بيع</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8 rtl:space-x-reverse">
          <Link to="/" className={`nav-link ${isActive("/") ? "active" : ""}`}>
            الرئيسية
          </Link>
          <Link to="/products" className={`nav-link ${isActive("/products") ? "active" : ""}`}>
            المنتجات
          </Link>
        </div>

        {/* Navigation Actions */}
        <div className="hidden md:flex items-center gap-4">
          {user ? (
            <>
              <Link to="/cart" className="relative">
                <Button variant="ghost" size="icon">
                  <ShoppingCart className="h-5 w-5" />
                  {totalItems > 0 && (
                    <span className="absolute -top-2 -right-2 bg-sawti-blue text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                      {totalItems}
                    </span>
                  )}
                </Button>
              </Link>
              <Link to="/profile">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.profileImage} />
                  <AvatarFallback className="default-avatar">
                    {user.name.substring(0, 1)}
                  </AvatarFallback>
                </Avatar>
              </Link>
            </>
          ) : (
            <Link to="/login">
              <Button variant="outline" size="sm" className="flex items-center gap-2">
                <User size={16} />
                <span>تسجيل الدخول</span>
              </Button>
            </Link>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden flex items-center"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t p-4 animate-fade-in">
          <div className="flex flex-col space-y-4">
            <Link
              to="/"
              className="px-2 py-1.5 rounded hover:bg-gray-100"
              onClick={() => setIsMenuOpen(false)}
            >
              الرئيسية
            </Link>
            <Link
              to="/products"
              className="px-2 py-1.5 rounded hover:bg-gray-100"
              onClick={() => setIsMenuOpen(false)}
            >
              المنتجات
            </Link>
            {user && (
              <Link
                to="/profile"
                className="px-2 py-1.5 rounded hover:bg-gray-100"
                onClick={() => setIsMenuOpen(false)}
              >
                الملف الشخصي
              </Link>
            )}
            <Link
              to="/cart"
              className="px-2 py-1.5 rounded hover:bg-gray-100 flex items-center justify-between"
              onClick={() => setIsMenuOpen(false)}
            >
              <span>سلة المشتريات</span>
              {totalItems > 0 && (
                <span className="bg-sawti-blue text-white rounded-full px-2 py-0.5 text-xs">
                  {totalItems}
                </span>
              )}
            </Link>
            {user ? (
              <Button
                variant="ghost"
                className="justify-start px-2 text-red-600"
                onClick={() => {
                  logout();
                  setIsMenuOpen(false);
                }}
              >
                تسجيل الخروج
              </Button>
            ) : (
              <Link
                to="/login"
                className="px-2 py-1.5 bg-sawti-blue text-white rounded text-center"
                onClick={() => setIsMenuOpen(false)}
              >
                تسجيل الدخول
              </Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
