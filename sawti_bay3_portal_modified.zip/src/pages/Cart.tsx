
import React from "react";
import { useNavigate, Link } from "react-router-dom";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import CartItem from "@/components/CartItem";
import { ShoppingCart, ArrowLeft } from "lucide-react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const Cart = () => {
  const { items, totalItems, totalPrice, clearCart } = useCart();
  const navigate = useNavigate();

  // حساب رسوم الشحن (مجانًا إذا كان إجمالي السعر أكثر من 200)
  const shippingFee = totalPrice > 200 ? 0 : 30;

  // حساب الضريبة (15% من إجمالي السعر)
  const taxRate = 0.15;
  const taxAmount = totalPrice * taxRate;

  // حساب المبلغ الإجمالي
  const grandTotal = totalPrice + shippingFee + taxAmount;

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center">سلة المشتريات</h1>

      {items.length === 0 ? (
        <div className="text-center py-16">
          <ShoppingCart className="mx-auto h-16 w-16 text-gray-300 mb-4" />
          <h2 className="text-2xl font-medium text-gray-600 mb-4">سلة المشتريات فارغة</h2>
          <p className="text-gray-500 mb-8">لم تقم بإضافة أي منتجات إلى سلة المشتريات بعد.</p>
          <Button
            asChild
            className="bg-sawti-blue hover:bg-blue-700"
          >
            <Link to="/products">تسوق الآن</Link>
          </Button>
        </div>
      ) : (
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-2/3">
            <Card>
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-medium">المنتجات ({totalItems})</h2>
                  <Button
                    variant="ghost"
                    className="text-red-600 hover:text-red-800 hover:bg-red-50"
                    onClick={clearCart}
                  >
                    إفراغ السلة
                  </Button>
                </div>
                <Separator className="mb-6" />
                <div className="space-y-6">
                  {items.map((item) => (
                    <CartItem key={item.product.id} item={item} />
                  ))}
                </div>
              </CardContent>
              <CardFooter className="p-6 pt-0">
                <Button
                  asChild
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <Link to="/products">
                    <ArrowLeft className="h-4 w-4" />
                    متابعة التسوق
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>

          <div className="lg:w-1/3">
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-medium mb-6">ملخص الطلب</h2>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">المجموع الفرعي</span>
                    <span>{totalPrice.toFixed(2)} ر.س</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">الشحن</span>
                    <span>
                      {shippingFee === 0 ? (
                        <span className="text-green-600">مجاني</span>
                      ) : (
                        `${shippingFee.toFixed(2)} ر.س`
                      )}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">الضريبة ({(taxRate * 100).toFixed(0)}%)</span>
                    <span>{taxAmount.toFixed(2)} ر.س</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-semibold text-lg">
                    <span>الإجمالي</span>
                    <span>{grandTotal.toFixed(2)} ر.س</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="p-6 pt-0">
                <Button
                  className="w-full bg-sawti-blue hover:bg-blue-700"
                  onClick={() => navigate("/checkout")}
                >
                  متابعة الدفع
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
